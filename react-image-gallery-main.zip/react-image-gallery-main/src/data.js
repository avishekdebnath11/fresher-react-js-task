const images = [
  { id: 1, thumbnail: "../src/assets/images/image-1.webp" },
  { id: 2, thumbnail: "../src/assets/images/image-2.webp" },
  { id: 3, thumbnail: "../src/assets/images/image-3.webp" },
  { id: 4, thumbnail: "../src/assets/images/image-4.webp" },
  { id: 5, thumbnail: "../src/assets/images/image-5.webp" },
  { id: 6, thumbnail: "../src/assets/images/image-6.webp" },
  { id: 7, thumbnail: "../src/assets/images/image-7.webp" },
  { id: 8, thumbnail: "../src/assets/images/image-8.webp" },
  { id: 9, thumbnail: "../src/assets/images/image-9.webp" },
  { id: 10, thumbnail: "../src/assets/images/image-10.jpeg" },
  { id: 11, thumbnail: "../src/assets/images/image-11.jpeg" },
];

export default images;
