import Gallery from "./components/Gallery";

function App() {
  return (
    <div className="bg-gray-100">
      <Gallery />
    </div>
  );
}

export default App;
